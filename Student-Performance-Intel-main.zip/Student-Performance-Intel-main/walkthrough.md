# 🚀 Project NEXUS: System Walkthrough

This guide explains how to operate the Next-Generation AI Student Intelligence System.

## 🏁 System Initialization

1.  **Execute `run_project.bat`**.
2.  **Select Option [2]** (Run Project Training) to initialize the AI Backend.
    -   *Why?* This trains **11 Advanced Models** (XGBoost, ANN, etc.) and generates the **3D PCA Projections** required for the dashboard.
    -   *Wait time*: ~1-2 minutes.
3.  **Select Option [3]** to launch the **NEXUS Dashboard**.

## 🎮 Dashboard Navigation

### Tab 1: 🏠 System Launch
-   **Live Metrics**: View real-time stats on the active dataset and best-performing algorithm.
-   **Status Check**: Ensure all systems are "ONLINE".

### Tab 2: 🔍 Data Explorer (EDA)
-   **3D Scatter Plot**: Rotate the graph to see how `StudyTime`, `Absences`, and `Grades` interact in 3D space.
-   **Distribution Scanner**: Select a feature (e.g., `health`) to see its impact on student results animated by age.

### Tab 3: 🤖 Supervised Models
-   **Leaderboard**: Automatically ranks all 11 algorithms from best to worst.
-   **Performance Comparison**: Horizontal bar chart visualizing the accuracy gap.

### Tab 4: 🌀 Unsupervised Lab
-   **Algorithm Switcher**: Toggle between `KMeans`, `DBSCAN`, `Hierarchical`, and `GMM`.
-   **3D Projection**: Watch the student clusters recolor dynamically based on the selected algorithm.

### Tab 5: 🔮 Prediction Engine
-   **Reality Sliders**: Adjust parameters like `Study Time`, `Alcohol`, and `Absences`.
-   **Confidence Gauge**: See the "Pass Probability" update instantly.
-   **Growth Trajectory**: A line chart projects the student's future academic path over 4 years based on current habits.
