@echo off
TITLE Advanced Student Intelligence System
CLS

:MENU
ECHO ========================================================
ECHO      STUDENT ACADEMIC PERFORMANCE INTELLIGENCE SYSTEM
ECHO ========================================================
ECHO.
ECHO  [1] Install Required Libraries
ECHO  [2] Run Project Training
ECHO  [3] Launch Intelligence Dashboard (Streamlit)
ECHO  [4] Exit
ECHO.
SET /P M="Select an Option (1-4): "

IF %M%==1 GOTO INSTALL
IF %M%==2 GOTO TRAIN
IF %M%==3 GOTO DASHBOARD
IF %M%==4 GOTO EOF

:INSTALL
ECHO.
ECHO Installing dependencies...
pip install -r requirements.txt
ECHO.
PAUSE
GOTO MENU

:TRAIN
ECHO.
ECHO Running Project Training...
python train_model.py
ECHO.
PAUSE
GOTO MENU

:DASHBOARD
ECHO.
ECHO Launching Dashboard...
streamlit run app.py
GOTO MENU
