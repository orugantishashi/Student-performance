# 🎓 Student Performance Intel: AI-Driven Analytics & Prediction

<div align="center">

![GitHub License](https://img.shields.io/github/license/othneildrew/Best-README-Template.svg?style=for-the-badge)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Streamlit](https://img.shields.io/badge/Streamlit-FF4B4B?style=for-the-badge&logo=Streamlit&logoColor=white)
![Scikit-Learn](https://img.shields.io/badge/scikit--learn-%23F7931E.svg?style=for-the-badge&logo=scikit-learn&logoColor=white)
![TensorFlow](https://img.shields.io/badge/TensorFlow-%23FF6F00.svg?style=for-the-badge&logo=TensorFlow&logoColor=white)

**A high-performance Machine Learning & Deep Learning system to analyze and predict student academic success.**

[Explore Features](#-key-capabilities) • [Installation](#-installation--setup) • [Model Performance](#-model-benchmarks) • [Quick Start](#-quick-start)

</div>

---

## 📑 Project Abstract

Predicting student performance is a critical task for educational institutions to provide timely support and improve overall academic outcomes. This project implements a comprehensive **Machine Learning & Deep Learning pipeline** to categorize student final results into three tiers: **Fail, Pass, and Distinction**. 

By analyzing various demographic, social, and academic indicators (e.g., study habits, parent background, lifestyle), the system offers actionable insights through a **Premium Streamlit Dashboard**. It combines **Supervised Learning** for prediction, **Unsupervised Learning** for clustering, and **Dimensionality Reduction** for deep data understanding.

---

## ✨ Key Capabilities

### 🕵️ 1. Intelligent EDA & Visualization
*   **Correlation Mapping**: Discover hidden relationships between lifestyle and grades.
*   **Dynamic Distribution**: interactive histograms and bar charts using Plotly.
*   **Data Health**: Real-time overview of the student dataset statistics.

### 🤖 2. Multi-Model Prediction Engine
We deploy a fleet of optimized classifiers, each tuned for maximum precision:
*   **Random Forest Classifier** (Top Performer)
*   **Support Vector Machines (SVM)** (Reliable Class Boundaries)
*   **Logistic Regression** (Baseline Interpretability)
*   **Decision Tree Classifier** (Logic Transparency)

### 🧠 3. Deep Learning Integration
*   **Artificial Neural Network (ANN)**: A custom Multi-Layer Perceptron (MLP) built with **TensorFlow/Keras** for capturing complex non-linear patterns in academic data.

### 🌀 4. Unsupervised Insights
*   **PCA (Principal Component Analysis)**: Dimensionality reduction for 2D/3D visual understanding.
*   **K-Means Clustering**: Grouping students into unique academic personas based on behavioral patterns.

---

## 🛠️ Tech Stack & Architecture

| Category | Tools |
| :--- | :--- |
| **Language** | ![Python](https://img.shields.io/badge/python-3572A5?style=flat-square&logo=python&logoColor=white) |
| **Framework** | ![Streamlit](https://img.shields.io/badge/Streamlit-FF4B4B?style=flat-square&logo=Streamlit&logoColor=white) |
| **Machine Learning** | ![Scikit-Learn](https://img.shields.io/badge/scikit--learn-F7931E?style=flat-square&logo=scikit-learn&logoColor=white) |
| **Deep Learning** | ![TensorFlow](https://img.shields.io/badge/TensorFlow-FF6F00?style=flat-square&logo=TensorFlow&logoColor=white) |
| **Visualization** | ![Matplotlib](https://img.shields.io/badge/Matplotlib-013243?style=flat-square) ![Seaborn](https://img.shields.io/badge/Seaborn-3776AB?style=flat-square) ![Plotly](https://img.shields.io/badge/Plotly-3F4F75?style=flat-square&logo=Plotly&logoColor=white) |

---

## 📁 Project Architecture

```bash
MACHINE-LEARNING-PROJECT/
├── data/
│   └── student_data.csv       # Primary Dataset (Demographics + Grades)
├── models/                    # Serialized Artifacts (.pkl, .h5, .npy)
├── visualizations/            # Auto-generated PNGs (Confusion Matrices, ROC)
├── app.py                     # High-Performance Streamlit Dashboard
├── train_model.py             # Core ML Engine (The "Brain")
├── run_project.bat            # One-Click Control center
├── requirements.txt           # Dependency Protocol
└── walkthrough.md             # Developer Onboarding
```

---

## 🚀 Installation & Setup

### 📦 1. Pre-requisites
Ensure you have Python 3.8+ installed on your system.

### ⚡ 2. Quick Execution (Recommended)
Simply double-click **`run_project.bat`** and follow the automated menu:
1.  **[1] Setup Environment**: Installs all required libraries.
2.  **[2] Initialize Training**: Builds the models and refreshes analytics.
3.  **[3] Launch Application**: Starts the interactive dashboard.

### ⌨️ 3. Developer Manual Mode
```bash
# Clone the repository and navigate inside
pip install -r requirements.txt

# Phase 1: Training & Artifact Generation
python train_model.py

# Phase 2: Launch the Interface
streamlit run app.py
```

---

## 📊 Model Benchmarks

| Algorithm | Accuracy | Precision | Verdict |
| :--- | :--- | :--- | :--- |
| **Random Forest** | **~90%** | **High** | ✅ Best for Production |
| **SVM (RBF Kernel)** | ~88% | Medium | ✅ Robust Performance |
| **Neural Network (ANN)** | ~85% | Medium | ✅ Captures Complexity |
| **Logistic Regression**| ~82% | Medium | ℹ️ Strong Baseline |

> [!NOTE]
> *Model performance may vary based on hyperparameter tuning and data splits.*

---

## 👤 Author & Acknowledgments

**Lead Developer**: **Botla Varshini**  
**Project Track**: Advanced Machine Learning Implementation  
**Academic Year**: 3rd Year | Term-3  

---
<div align="center">
  Developed with ❤️ at Aurora Deemed to be University
</div>
