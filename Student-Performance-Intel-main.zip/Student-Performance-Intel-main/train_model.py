
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
import os

from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_curve, auc
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer

# TensorFlow for ANN
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import to_categorical

# Create directories if not exist
os.makedirs("models", exist_ok=True)
os.makedirs("visualizations", exist_ok=True)

# -------------------------------------------
# 1. Load and Preprocess Data
# -------------------------------------------
def load_and_preprocess_data(filepath):
    print("Loading data...")
    df = pd.read_csv(filepath)
    
    # Target creation
    df['result'] = df['G3'].apply(lambda x: 0 if x < 10 else (1 if x < 15 else 2))
    
    # Drop data leakage columns
    df = df.drop(['G1', 'G2', 'G3'], axis=1)
    
    # Separate features and target
    X = df.drop("result", axis=1)
    
    # Split categorical and numerical
    categorical_cols = X.select_dtypes(include=['object']).columns
    numerical_cols = X.select_dtypes(include=['int64', 'float64']).columns
    
    # Preprocessing Pipeline
    # We will use ColumnTransformer to apply different preprocessing to different columns
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_cols),
            ('cat', OneHotEncoder(drop='first', sparse_output=False), categorical_cols)
        ]
    )
    
    # Return raw data for splitting and preprocessor
    return df, X, df['result'], preprocessor

# -------------------------------------------
# 2. Train Models with GridSearchCV
# -------------------------------------------
def train_ml_models(X_train, y_train):
    print("Training ML Models...")
    
    models = {
        'Logistic Regression': {
            'model': LogisticRegression(max_iter=1000, random_state=42),
            'params': {
                'C': [0.1, 1, 10], 
                'solver': ['liblinear', 'lbfgs']
            }
        },
        'SVM': {
            'model': SVC(probability=True, random_state=42),
            'params': {
                'C': [0.1, 1, 10],
                'kernel': ['rbf', 'linear'],
                'gamma': ['scale', 'auto']
            }
        },
        'Decision Tree': {
            'model': DecisionTreeClassifier(random_state=42),
            'params': {
                'max_depth': [None, 10, 20, 30],
                'min_samples_split': [2, 5, 10]
            }
        },
        'Random Forest': {
            'model': RandomForestClassifier(random_state=42),
            'params': {
                'n_estimators': [50, 100, 200],
                'max_depth': [None, 10, 20]
            }
        }
    }
    
    best_models = {}
    
    for name, m in models.items():
        print(f"Tuning {name}...")
        clf = GridSearchCV(m['model'], m['params'], cv=5, n_jobs=-1, scoring='accuracy')
        clf.fit(X_train, y_train)
        best_models[name] = clf.best_estimator_
        print(f"Best {name}: {clf.best_score_:.4f}")
        
    return best_models

# -------------------------------------------
# 3. Train ANN (MLP)
# -------------------------------------------
def train_ann(X_train, y_train, input_dim):
    print("Training ANN...")
    y_train_cat = to_categorical(y_train)
    
    model = Sequential([
        Dense(64, activation='relu', input_shape=(input_dim,)),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dropout(0.2),
        Dense(3, activation='softmax') # 3 classes: 0, 1, 2
    ])
    
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    
    history = model.fit(X_train, y_train_cat, epochs=50, batch_size=32, validation_split=0.2, verbose=0)
    
    # Save training history for plotting
    return model, history

# -------------------------------------------
# 4. Unsupervised Learning
# -------------------------------------------
def perform_unsupervised(X_scaled):
    print("Performing Unsupervised Learning...")
    
    # PCA
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    joblib.dump(pca, "models/pca_model.pkl")
    
    # KMeans
    kmeans = KMeans(n_clusters=3, random_state=42, n_init='auto')
    clusters = kmeans.fit_predict(X_scaled)
    joblib.dump(kmeans, "models/kmeans_model.pkl")
    
    return X_pca, clusters

# -------------------------------------------
# 5. Evaluation and Plots
# -------------------------------------------
def evaluate_and_plot(models, X_test, y_test, ann_model=None):
    print("Evaluating models...")
    
    results = {}
    
    # ML Models
    for name, model in models.items():
        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        results[name] = acc
        
        print(f"\nModel: {name}")
        print(classification_report(y_test, y_pred))
        
        # Confusion Matrix
        cm = confusion_matrix(y_test, y_pred)
        plt.figure(figsize=(6, 4))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title(f'Confusion Matrix - {name}')
        plt.ylabel('Actual')
        plt.xlabel('Predicted')
        plt.savefig(f"visualizations/cm_{name.replace(' ', '_')}.png")
        plt.close()
    
    # ANN Evaluation
    if ann_model:
        y_pred_ann_prob = ann_model.predict(X_test)
        y_pred_ann = np.argmax(y_pred_ann_prob, axis=1)
        acc_ann = accuracy_score(y_test, y_pred_ann)
        results['ANN'] = acc_ann
        print("\nModel: ANN")
        print(classification_report(y_test, y_pred_ann))
        
        cm = confusion_matrix(y_test, y_pred_ann)
        plt.figure(figsize=(6, 4))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title('Confusion Matrix - ANN')
        plt.savefig("visualizations/cm_ANN.png")
        plt.close()

    # Save Results
    joblib.dump(results, "models/model_performance.pkl")
    return results

# -------------------------------------------
# 6. Additional Visualizations
# -------------------------------------------
def plot_roc_curves(models, X_test, y_test):
    print("Plotting ROC Curves...")
    plt.figure(figsize=(10, 8))
    
    # Binarize the output for multiclass ROC
    from sklearn.preprocessing import label_binarize
    y_test_bin = label_binarize(y_test, classes=[0, 1, 2])
    n_classes = y_test_bin.shape[1]
    
    for name, model in models.items():
        if hasattr(model, "predict_proba"):
            y_score = model.predict_proba(X_test)
            
            # Compute ROC curve and ROC area for each class
            fpr = dict()
            tpr = dict()
            roc_auc = dict()
            for i in range(n_classes):
                fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_score[:, i])
                roc_auc[i] = auc(fpr[i], tpr[i])
            
            # Compute micro-average ROC curve and ROC area
            fpr["micro"], tpr["micro"], _ = roc_curve(y_test_bin.ravel(), y_score.ravel())
            roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
            
            plt.plot(fpr["micro"], tpr["micro"], label=f'{name} (area = {roc_auc["micro"]:.2f})')

    plt.plot([0, 1], [0, 1], 'k--', lw=2)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (Micro-averaged)')
    plt.legend(loc="lower right")
    plt.savefig("visualizations/roc_curve.png")
    plt.close()

def plot_feature_importance(model, feature_names):
    print("Plotting Feature Importance...")
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
        indices = np.argsort(importances)[::-1]
        
        # Take top 10
        top_n = 10
        indices = indices[:top_n]
        
        plt.figure(figsize=(10, 6))
        plt.title("Feature Importances (Top 10)")
        plt.bar(range(top_n), importances[indices], align="center")
        # We need to handle feature names properly from OneHotEncoding
        # reliable feature names might be tricky if not stored, 
        # but we can try to get them from best effort or skip specific labels
        plt.tight_layout()
        plt.savefig("visualizations/feature_importance.png")
        plt.close()

def plot_clusters(X_pca, clusters):
    print("Plotting Clusters...")
    plt.figure(figsize=(8, 6))
    plt.scatter(X_pca[:, 0], X_pca[:, 1], c=clusters, cmap='viridis', s=50, alpha=0.6)
    plt.title('K-Means Clustering (PCA Reduced)')
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    plt.colorbar(label='Cluster')
    plt.savefig("visualizations/clusters.png")
    plt.close()

# -------------------------------------------
# Main Execution
# -------------------------------------------
if __name__ == "__main__":
    df, X, y, preprocessor = load_and_preprocess_data("data/student_data.csv")
    
    # Fit and transform data
    X_processed = preprocessor.fit_transform(X)
    
    # Save preprocessor
    joblib.dump(preprocessor, "models/preprocessor.pkl")
    
    # Train Test Split
    X_train, X_test, y_train, y_test = train_test_split(X_processed, y, test_size=0.2, random_state=42)
    
    # Save Split Data for Dashboard usage
    joblib.dump((X_test, y_test), "models/test_data.pkl")
    joblib.dump((X_train, y_train), "models/train_data.pkl")
    
    # ML Training
    trained_models = train_ml_models(X_train, y_train)
    
    # Save Best ML Models
    joblib.dump(trained_models, "models/all_models.pkl")
    # For compatibility, save the Random Forest as the "main" trained_model.pkl
    joblib.dump(trained_models['Random Forest'], "models/trained_model.pkl") 
    
    # ANN Training
    try:
        ann_model, history = train_ann(X_train, y_train, X_train.shape[1])
        ann_model.save("models/ann_model.h5")
        joblib.dump(history.history, "models/ann_history.pkl")
        
        # Plot ANN History
        plt.figure(figsize=(10, 4))
        plt.subplot(1, 2, 1)
        plt.plot(history.history['accuracy'], label='Train')
        plt.plot(history.history['val_accuracy'], label='Val')
        plt.title('Model Accuracy')
        plt.legend()
        plt.subplot(1, 2, 2)
        plt.plot(history.history['loss'], label='Train')
        plt.plot(history.history['val_loss'], label='Val')
        plt.title('Model Loss')
        plt.legend()
        plt.savefig("visualizations/ann_learning_curve.png")
        plt.close()
    except Exception as e:
        print(f"ANN Training failed: {e}")
        ann_model = None

    # Unsupervised
    X_pca, clusters = perform_unsupervised(X_processed)
    # Save PCA data for plotting
    np.save("models/X_pca.npy", X_pca)
    np.save("models/clusters.npy", clusters)
    
    # Visualizations
    plot_clusters(X_pca, clusters)
    plot_roc_curves(trained_models, X_test, y_test)
    
    # Feature Importance (Random Forest)
    if 'Random Forest' in trained_models:
        rf_model = trained_models['Random Forest']
        # Try to get feature names from preprocessor
        feature_names = preprocessor.get_feature_names_out()
        
        plt.figure(figsize=(10, 12))
        importances = rf_model.feature_importances_
        indices = np.argsort(importances)[::-1][:20] # Top 20
        plt.title("Feature Importances (Top 20)")
        plt.barh(range(len(indices)), importances[indices], align="center")
        plt.yticks(range(len(indices)), [feature_names[i] for i in indices])
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig("visualizations/feature_importance.png")
        plt.close()
    
    # Evaluation
    metrics = evaluate_and_plot(trained_models, X_test, y_test, ann_model)
    
    print("\nTraining Complete! All artifacts saved.")
    print("Model Performance:", metrics)
